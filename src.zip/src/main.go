/*
Copyright © 2025 Vinzenz Stadtmueller vinzenz.stadtmueller@fh-hagenberg.at
*/
package main

import "sdx/recipe/cmd"

func main() {
	cmd.Execute()
}
